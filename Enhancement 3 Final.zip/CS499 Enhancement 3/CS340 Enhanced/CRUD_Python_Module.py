# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username 
        PASS = password 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

        # created 3 indexes to improve database searching
        self.collection.create_index("name")
        self.collection.create_index("breed")
        self.collection.create_index("age_upon_outcome")

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            self.database.animals.insert_one(data)  # data should be dictionary             
        else: 
            raise Exception("Data parameter is empty") 

    # Read method to implement the R in CRUD.
    def read(self, query):
        return list(self.database.animals.find(query))

    # Update method to implement the U in CRUD.
    def update(self, query, new_values):
        if query is not None and new_values is not None:
            result = self.database.animals.update_many(query, {"$set": new_values})
            return result.modified_count
        else:
            raise Exception("Query or update data is empty")

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        if query is not None:
            result = self.database.animals.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Query parameter is empty")

    # added to allow searching via multiple criteria
    def search_animals(self, name="", breed="", age=""):
        query = {}
        
        # validate search inputs before querying MongoDB
        for value in (name, breed, age):
            if not isinstance(value, str) or len(value) > 100:
                raise ValueError("Invalid search input")

        if name.strip():
            query["name"] = {"$regex": name.strip(), "$options": "i"}

        if breed.strip():
            query["breed"] = {"$regex": breed.strip(), "$options": "i"}

        if age.strip():
            query["age_upon_outcome"] = age.strip()

        return list(self.collection.find(query))
